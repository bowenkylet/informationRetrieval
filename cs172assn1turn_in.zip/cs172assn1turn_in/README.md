# CS172 - Assignment 1 (Tokenization)

## Team member 1 - Kyle Bowen

###### parser.ipynb parses the documents and saves information to docids.txt, termids.txt, term_index.txt, and term_info.txt according to the given schema, with the modification that docids.txt contains a third field TOKENCOUNT, an int that stores the number of tokens in a document, used in --doc DOCNAME option
###### Python, string, argparse libraries. To create inverted index and associated files, run parser.ipynb on a jupyter notebooks window or run "jupyter nbconvert --to python parser.ipynb" and run parser.py. (Before submitting I pasted my ipynb code into parsing.py but it took 3 hours to make the files so I'm not messing with it until after assn1 submission.) With the files in place, run read_index.py with --doc DOCNAME and --term TERM options. Extra credit was attempted.