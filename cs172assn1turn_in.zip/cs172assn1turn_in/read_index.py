# This file should contain code to receive either a document-id or word or both and output the required metrics. See the assignment description for more detail.
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("-D", "--doc")
parser.add_argument("-T", "--term")

args = parser.parse_args()

if args.term:
    termid=-1
    termids=open("termids.txt","r")
    while termids:
        inline = termids.readline().split("\t")
        if inline[1].rstrip("\n") == args.term:
            termid = inline[0]
            break
    termids.close()
    if args.doc:
        print("Inverted list for term: "+args.term)
        print("In document: "+args.doc)
        docid=" "
        docids=open("docids.txt","r")
        while docids:
            inline = docids.readline().split("\t")
            if inline[1] == args.doc:
                docid = inline[0]
                break
        docids.close()
        byteoffset=0
        term_info=open("term_info.txt","r")
        while term_info:
            inline = term_info.readline().split("\t")
            if inline[0] == termid:
                byteoffset = int(inline[1])
                break
        term_info.close()        
        term_index=open("term_index.txt","r")
        #seek by byteoffset
        term_index.seek(byteoffset)
        inline = term_index.readline().split("\t")
        positions=[]
        for i in inline[1:]:
            a,b=i.split(":")
            if a==docid:
                positions.append(str(b))
        term_index.close()
        print("TERMID: "+termid+"\n"+"DOCID: "+str(docid))
        print("Term frequency in document: "+str(len(positions)))
        print("Positions: "+", ".join(positions))
    else:
        print("Listing for term: "+args.term)
        print("TERMID: "+termid)
        #open term_info.txt
        docswith=0
        numoccur=0
        term_info=open("term_info.txt","r")
        while term_info:
            inline = term_info.readline().split("\t")
            if inline[0] == termid:
                docswith = inline[3]
                numoccur = inline[2]
                break
        term_info.close()
        print("Number of documents containing term: "+docswith.rstrip("\n"))
        print("Term frequency in corpus: "+str(numoccur))
elif args.doc:
    print("Listing for document: "+args.doc)
    docid=" "
    tokencount=-1
    docids=open("docids.txt","r")
    while docids:
        inline = docids.readline().split("\t")
        if inline[1] == args.doc:
            docid = inline[0]
            tokencount=inline[2]
            break
    docids.close()
    print("DOCID: "+str(docid))
    print("Total terms: "+tokencount.rstrip("\n"))
else:
    print("No doc or term arguments provided")